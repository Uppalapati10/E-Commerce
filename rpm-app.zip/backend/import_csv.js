const fs = require('fs');
const path = require('path');
const parse = require('csv-parse');
const { db, init } = require('./db');

init();

const csvPath = path.join(__dirname, 'data', 'Patient_data.csv');
if (!fs.existsSync(csvPath)) {
  console.error('CSV not found at', csvPath);
  process.exit(1);
}

const parser = fs.createReadStream(csvPath).pipe(parse({ columns: true, trim: true }));
const insertPatient = db.prepare('INSERT OR IGNORE INTO patients (id, name, dob) VALUES (?, ?, ?)');
const insertDevice = db.prepare('INSERT OR IGNORE INTO devices (device_id, patient_id, meta) VALUES (?, ?, ?)');
const insertVitals = db.prepare(`INSERT INTO vitals (patient_id, device_id, timestamp, systolic, diastolic, glucose, hr, spo2)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);

parser.on('data', (row) => {
  const pid = row.patient_id || row.PatientID || row.PatientId || row.id || row.ID;
  if (!pid) return;
  insertPatient.run(pid, row.name || `Patient ${pid}`, row.dob || null);
  const did = row.device_id || row.deviceId || 'unknown';
  insertDevice.run(did, pid, row.device_meta || null);

  insertVitals.run(
    pid,
    did,
    row.timestamp || row.ts || new Date().toISOString(),
    row.systolic ? parseInt(row.systolic) : (row.bp_systolic ? parseInt(row.bp_systolic) : null),
    row.diastolic ? parseInt(row.diastolic) : (row.bp_diastolic ? parseInt(row.bp_diastolic) : null),
    row.glucose ? parseFloat(row.glucose) : null,
    row.hr ? parseInt(row.hr) : (row.heart_rate ? parseInt(row.heart_rate) : null),
    row.spo2 ? parseFloat(row.spo2) : (row.o2 ? parseFloat(row.o2) : null)
  );
});

parser.on('end', () => {
  console.log('CSV import completed.');
});
