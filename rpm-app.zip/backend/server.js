const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const { db, init } = require('./db');
const authRoutes = require('./routes/auth');
const patientsRoutes = require('./routes/patients');

init();
const app = express();
app.use(cors());
app.use(bodyParser.json());
app.locals.db = db;

app.use('/auth', authRoutes);
app.use('/patients', patientsRoutes);

// Serve static frontend if built into backend 'frontend/dist'
const dist = path.join(__dirname, '..', 'frontend', 'dist');
app.use(express.static(dist));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/auth') || req.path.startsWith('/patients')) return;
  res.sendFile(path.join(dist, 'index.html'), err => {
    if (err) res.status(404).send('Not found');
  });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on ${PORT}`));
