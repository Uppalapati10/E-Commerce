const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const rows = req.app.locals.db.prepare('SELECT id, name FROM patients').all();
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const id = req.params.id;
  const vitals = req.app.locals.db.prepare('SELECT * FROM vitals WHERE patient_id = ? ORDER BY timestamp').all(id);
  const devices = req.app.locals.db.prepare('SELECT * FROM devices WHERE patient_id = ?').all(id);
  res.json({ vitals, devices });
});

router.get('/:id/summary', (req, res) => {
  const id = req.params.id;
  const vitals = req.app.locals.db.prepare('SELECT systolic, diastolic, glucose, hr, spo2, timestamp FROM vitals WHERE patient_id = ? ORDER BY timestamp').all(id);
  if (!vitals || vitals.length===0) return res.json({ summary: 'No readings available.' });

  const numeric = (k) => vitals.map(v => v[k]).filter(x => x != null);
  const avg = arr => Math.round(arr.reduce((a,b)=>a+b,0)/arr.length);

  const meanSys = numeric('systolic').length ? avg(numeric('systolic')) : null;
  const meanDia = numeric('diastolic').length ? avg(numeric('diastolic')) : null;
  const meanGlucose = numeric('glucose').length ? Math.round(numeric('glucose').reduce((a,b)=>a+b,0)/numeric('glucose').length) : null;
  const meanHr = numeric('hr').length ? avg(numeric('hr')) : null;
  const meanSpO2 = numeric('spo2').length ? Math.round(numeric('spo2').reduce((a,b)=>a+b,0)/numeric('spo2').length) : null;

  const issues = [];
  if (meanSys !== null && meanDia !== null && (meanSys >= 140 || meanDia >= 90)) issues.push('Elevated blood pressure (hypertensive range).');
  if (meanGlucose !== null && meanGlucose >= 180) issues.push('High average glucose — possible hyperglycemia.');
  if (meanSpO2 !== null && meanSpO2 < 92) issues.push('Low oxygen saturation readings detected.');
  if (meanHr !== null && meanHr > 100) issues.push('Elevated heart rate on average.');

  const summary = `Patient ${id}: Avg BP ${meanSys || 'N/A'}/${meanDia || 'N/A'} mmHg, Glucose ~${meanGlucose || 'N/A'} mg/dL, HR avg ${meanHr || 'N/A'} bpm, SpO₂ avg ${meanSpO2 || 'N/A'}%. ${issues.length ? 'Issues: ' + issues.join(' ') : 'Vitals within expected ranges.'}`;

  res.json({ summary, metrics: { meanSys, meanDia, meanGlucose, meanHr, meanSpO2 } });
});

module.exports = router;
