const express = require('express');
const router = express.Router();

const DOCTOR_EMAIL = 'doctor@doc.com';
const DOCTOR_PASS = '12345';

router.post('/doctor', (req, res) => {
  const { email, password } = req.body;
  if (email === DOCTOR_EMAIL && password === DOCTOR_PASS) {
    return res.json({ ok: true, role: 'doctor' });
  }
  res.status(401).json({ ok: false, message: 'Invalid credentials' });
});

router.post('/patient/:id', (req, res) => {
  const pid = req.params.id;
  const row = req.app.locals.db.prepare('SELECT id FROM patients WHERE id = ?').get(pid);
  if (row) return res.json({ ok: true, patientId: pid });
  return res.status(404).json({ ok: false, message: 'Patient not found' });
});

module.exports = router;
