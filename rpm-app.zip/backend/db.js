const Database = require('better-sqlite3');
const db = new Database('rpm.sqlite');

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS patients (
      id TEXT PRIMARY KEY,
      name TEXT,
      dob TEXT
    );
    CREATE TABLE IF NOT EXISTS devices (
      device_id TEXT PRIMARY KEY,
      patient_id TEXT,
      meta TEXT
    );
    CREATE TABLE IF NOT EXISTS vitals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id TEXT,
      device_id TEXT,
      timestamp TEXT,
      systolic INTEGER,
      diastolic INTEGER,
      glucose REAL,
      hr INTEGER,
      spo2 REAL
    );
  `);
}

module.exports = { db, init };
