# RPM Web App (Doctor + Patient portals)

## Quick start (local)
1. Backend
   - cd backend
   - npm install
   - place your Patient_data.csv into backend/data/Patient_data.csv
   - npm run import
   - npm start
2. Frontend
   - cd frontend
   - npm install
   - create .env with VITE_API_BASE=http://localhost:4000
   - npm run dev

Doctor credentials: doctor@doc.com / 12345
Patient login: enter patient ID found in the CSV.

## Deploy
See Dockerfile and Render notes in repository.
