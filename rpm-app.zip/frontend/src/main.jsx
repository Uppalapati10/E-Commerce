import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import App from './App'
import DoctorLogin from './pages/DoctorLogin'
import DoctorPatients from './pages/DoctorPatients'
import DoctorPatientDetail from './pages/DoctorPatientDetail'
import PatientLogin from './pages/PatientLogin'
import PatientPortal from './pages/PatientPortal'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App/>} />
        <Route path='/doctor/login' element={<DoctorLogin/>} />
        <Route path='/doctor/patients' element={<DoctorPatients/>} />
        <Route path='/doctor/patient/:id' element={<DoctorPatientDetail/>} />
        <Route path='/patient/login' element={<PatientLogin/>} />
        <Route path='/patient/:id' element={<PatientPortalWrapper/>} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);

function PatientPortalWrapper() {
  const { pathname } = window.location;
  const id = pathname.split('/').pop();
  return <PatientPortal patientId={id} />;
}
