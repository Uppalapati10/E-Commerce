import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function PatientPortal({ patientId }) {
  const [data, setData] = useState({ vitals: [], devices: [] });
  const [summary, setSummary] = useState('');

  useEffect(() => {
    const base = import.meta.env.VITE_API_BASE || '';
    axios.get(`${base}/patients/${patientId}`).then(r => setData(r.data)).catch(()=>setData({ vitals: [], devices: [] }));
    axios.get(`${base}/patients/${patientId}/summary`).then(r => setSummary(r.data.summary)).catch(()=>setSummary('No summary available'));
  }, [patientId]);

  function speak() {
    if (!('speechSynthesis' in window)) return alert('TTS not supported in this browser.');
    const utter = new SpeechSynthesisUtterance(summary);
    utter.lang = 'en-US';
    utter.rate = 0.95;
    window.speechSynthesis.speak(utter);
  }

  return (
    <div className="container" style={{ fontSize: '20px' }}>
      <h1>Patient {patientId}</h1>
      <section aria-label="Health Summary">
        <h2>Auto-generated summary</h2>
        <p>{summary}</p>
        <button onClick={speak} aria-label="Listen to summary">🔊 Listen</button>
      </section>

      <section aria-label="Vitals">
        <h2>Vitals (recent)</h2>
        <table role="table" style={{ width:'100%', fontSize: '18px' }}>
          <thead>
            <tr><th>Time</th><th>BP</th><th>Glucose</th><th>HR</th><th>SpO₂</th></tr>
          </thead>
          <tbody>
            {data.vitals.slice(-10).reverse().map((v, i)=>(
              <tr key={i}>
                <td>{v.timestamp}</td>
                <td>{v.systolic}/{v.diastolic}</td>
                <td>{v.glucose}</td>
                <td>{v.hr}</td>
                <td>{v.spo2}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section aria-label="Device performance">
        <h2>Device performance</h2>
        <ul>
          {data.devices.map(d => <li key={d.device_id}>{d.device_id} — meta: {d.meta}</li>)}
        </ul>
      </section>
    </div>
  );
}
