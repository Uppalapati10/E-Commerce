import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default function DoctorPatients(){
  const [patients, setPatients] = useState([]);
  useEffect(()=>{
    const base = import.meta.env.VITE_API_BASE || '';
    axios.get(`${base}/patients`).then(r=>setPatients(r.data)).catch(()=>setPatients([]));
  },[]);
  return (
    <div className="container">
      <h1>All Patients</h1>
      <table className="patients-table">
        <thead><tr><th>Patient ID</th><th>Name</th></tr></thead>
        <tbody>
          {patients.map(p=>(
            <tr key={p.id}>
              <td><Link to={`/doctor/patient/${p.id}`}>{p.id}</Link></td>
              <td>{p.name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
