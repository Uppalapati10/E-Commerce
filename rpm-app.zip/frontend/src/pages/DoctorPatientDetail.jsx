import React, {useEffect, useState} from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function DoctorPatientDetail(){
  const { id } = useParams();
  const [data, setData] = useState({ vitals: [], devices: [] });
  const [summary, setSummary] = useState('');
  useEffect(()=>{
    const base = import.meta.env.VITE_API_BASE || '';
    axios.get(`${base}/patients/${id}`).then(r=>setData(r.data)).catch(()=>{});
    axios.get(`${base}/patients/${id}/summary`).then(r=>setSummary(r.data.summary)).catch(()=>{});
  },[id]);

  return (
    <div className="container">
      <h1>Patient {id}</h1>
      <section>
        <h2>Summary</h2>
        <p>{summary}</p>
        <button onClick={()=>{ if(window.speechSynthesis){ window.speechSynthesis.speak(new SpeechSynthesisUtterance(summary)); } }}>🔊 Listen</button>
      </section>
      <section>
        <h2>Recent Vitals</h2>
        <table>
          <thead><tr><th>Time</th><th>BP</th><th>Glucose</th><th>HR</th><th>SpO₂</th></tr></thead>
          <tbody>
            {data.vitals.slice().reverse().slice(0,20).map((v,i)=>(
              <tr key={i}>
                <td>{v.timestamp}</td>
                <td>{v.systolic}/{v.diastolic}</td>
                <td>{v.glucose}</td>
                <td>{v.hr}</td>
                <td>{v.spo2}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
