import React, {useState} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function DoctorLogin(){
  const [email, setEmail] = useState('doctor@doc.com');
  const [password, setPassword] = useState('12345');
  const nav = useNavigate();

  async function submit(e){
    e.preventDefault();
    try {
      const base = import.meta.env.VITE_API_BASE || '';
      await axios.post(`${base}/auth/doctor`, { email, password });
      nav('/doctor/patients');
    } catch (err) {
      alert('Login failed');
    }
  }

  return (
    <div className="container">
      <h1>Doctor Login</h1>
      <form onSubmit={submit}>
        <label>Email<br/><input value={email} onChange={e=>setEmail(e.target.value)} /></label><br/>
        <label>Password<br/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} /></label><br/>
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
