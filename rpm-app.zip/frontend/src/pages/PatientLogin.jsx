import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export default function PatientLogin(){
  const [id, setId] = useState('');
  const nav = useNavigate();
  async function submit(e){
    e.preventDefault();
    const base = import.meta.env.VITE_API_BASE || '';
    try {
      await axios.post(`${base}/auth/patient/${id}`, {});
      nav('/patient/'+id);
    } catch (err){
      alert('Patient not found');
    }
  }
  return (
    <div className="container">
      <h1>Patient Login</h1>
      <form onSubmit={submit}>
        <label>Patient ID<br/><input value={id} onChange={e=>setId(e.target.value)} /></label><br/>
        <button type="submit">Enter</button>
      </form>
    </div>
  );
}
