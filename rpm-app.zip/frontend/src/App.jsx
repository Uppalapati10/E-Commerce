import React from 'react';
import { Link } from 'react-router-dom';
export default function App(){
  return (
    <div className="container">
      <h1>RPM Web App</h1>
      <p>
        <Link to="/doctor/login">Doctor Portal</Link> | <Link to="/patient/login">Patient Portal</Link>
      </p>
    </div>
  );
}
